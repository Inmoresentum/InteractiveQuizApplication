exports.id = 899;
exports.ids = [899];
exports.modules = {

/***/ 60603:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 69105))

/***/ }),

/***/ 69105:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Navbar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(31621);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_rx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2175);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(75655);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(17808);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(83751);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(64348);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(16775);
/* harmony import */ var react_icons_pi__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(32017);
/* __next_internal_client_entry_do_not_use__ default auto */ 









function Navbar() {
    const pathName = (0,next_navigation__WEBPACK_IMPORTED_MODULE_2__.usePathname)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "fixed w-20 h-screen p-4 bg-white border-r-[1px] flex flex-col justify-between",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex flex-col items-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: "/dashboard/admin/activity",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: pathName === "/dashboard/admin/activity" ? "bg-purple-800 text-white p-3 rounded-lg" + " inline-block hover:opacity-75 duration-300 ease-linear" : "bg-gray-300 text-black p-3 rounded-lg inline-block hover:bg-rose-600 hover:text-white duration-300 ease-in",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_3__/* .MdLocalActivity */ .G4S, {
                            size: 20
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "border-b-[1px] border-gray-200 w-full p-2"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: "/dashboard/admin/homepage/cms",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: pathName === "/dashboard/admin/homepage/cms" ? "bg-purple-800 text-white p-3 rounded-lg " + "inline-block hover:opacity-75 duration-300 ease-linear" : "bg-gray-300 text-black p-3 rounded-lg inline-block hover:bg-rose-600 hover:text-white duration-300 ease-in",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_rx__WEBPACK_IMPORTED_MODULE_4__/* .RxDashboard */ .toC, {
                            size: 20
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: "/dashboard/admin/allusers",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: pathName === "/dashboard/admin/allusers" ? "bg-purple-800 text-white p-3 rounded-lg " + "inline-block hover:opacity-75 duration-300 ease-linear" : "bg-gray-300 text-black p-3 rounded-lg inline-block hover:bg-rose-600 hover:text-white duration-300 ease-in",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_5__/* .RiUserSettingsFill */ .ks3, {
                            size: 20
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: "/dashboard/admin/subscription",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: pathName === "/dashboard/admin/subscription" ? "bg-purple-800 text-white p-3 rounded-lg " + "inline-block hover:opacity-75 duration-300 ease-linear" : "bg-gray-300 text-black p-3 rounded-lg inline-block hover:bg-rose-600 hover:text-white duration-300 ease-in",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_6__.HiOutlineShoppingBag, {
                            size: 20
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: "/dashboard/admin/blogs/settings",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: pathName === "/dashboard/admin/blogs/settings" ? "bg-purple-800 text-white p-3 rounded-lg " + "inline-block hover:opacity-75 duration-300 ease-linear" : "bg-gray-300 text-black p-3 rounded-lg inline-block hover:bg-rose-600 hover:text-white duration-300 ease-in",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_pi__WEBPACK_IMPORTED_MODULE_7__/* .PiPencilFill */ .I5x, {
                            size: 20
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: "/dashboard/admin/faqs",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: pathName === "/dashboard/admin/faqs" ? "bg-purple-800 text-white p-3 rounded-lg " + "inline-block hover:opacity-75 duration-300 ease-linear" : "bg-gray-300 text-black p-3 rounded-lg inline-block hover:bg-rose-600 hover:text-white duration-300 ease-in",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_8__.FaQuestion, {
                            size: 20
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: "/dashboard/admin/support",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: pathName === "/dashboard/admin/support" ? "bg-purple-800 text-white p-3 rounded-lg " + "inline-block hover:opacity-75 duration-300 ease-linear" : "bg-gray-300 text-black p-3 rounded-lg inline-block hover:bg-rose-600 hover:text-white duration-300 ease-in",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_9__/* .FiSettings */ .nbt, {
                            size: 20
                        })
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 77066:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ LoginPageLayout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21313);
;// CONCATENATED MODULE: ./components/Dashboard/Admin/Navbar.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`/home/runner/work/InteractiveQuizApplication/InteractiveQuizApplication/FrontEnd/interactive-quiz-app/components/Dashboard/Admin/Navbar.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Navbar = (__default__);
;// CONCATENATED MODULE: ./app/dashboard/admin/layout.js


const metadata = {
    title: "Dashboard",
    description: "The Admin Dashboard is a powerful web-based interface," + " offering centralized control, customizable widgets, user and content management," + " robust analytics, system monitoring, and security features." + " With its intuitive design and cross-platform accessibility," + " administrators can efficiently manage their digital assets," + " gain valuable insights, and make data-driven decisions," + " driving the success of their organization with ease."
};
function LoginPageLayout({ children }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Navbar, {}),
                /*#__PURE__*/ jsx_runtime_.jsx("main", {
                    className: "ml-20 w-full",
                    children: children
                })
            ]
        })
    });
}


/***/ })

};
;