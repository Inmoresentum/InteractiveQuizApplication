"use strict";
exports.id = 148;
exports.ids = [148];
exports.modules = {

/***/ 68495:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/quiz-app-logo.1a3a0370.png","height":2048,"width":2048,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA/0lEQVR4nA2OPUtCYRhAz3M//MgalDIwHIQicGppaBWamhobmqOhcPJ3tNTY0g+QZtEMCwNBAgctiqiQCgnqKl3q9t7Hu50DZzhSa6RVrBzILLb0cJwkxggm/IvcValflTSe2cSNxXgeXOMN71gvLnA/nGDcT5Vmt6xOchHvO+CkGmJ1q1QOc/T6hv3KP3LZLmlgb/DmF7HHQ9JfZzx95Gh0Al5Hggxu1zRtJXh8cVgpJPB/LfoPIYW88D6K1m7aec1Yq4w9m3gsJDUjpJJETDQaBc3WnPb6eQ72ltjaNkx8obIrZOeFVkeR+kVWTehwfLrMecuFH6W8IxzVFAYwBbsDZGen4HKfAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 40668:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/react.3b0445a3.svg","height":32,"width":36,"blurWidth":0,"blurHeight":0});

/***/ })

};
;