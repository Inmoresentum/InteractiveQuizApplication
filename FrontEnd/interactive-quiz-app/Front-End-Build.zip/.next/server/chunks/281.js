"use strict";
exports.id = 281;
exports.ids = [281];
exports.modules = {

/***/ 45720:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Navbar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(19722);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(48421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _public_quiz_app_logo_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(68495);
/* harmony import */ var _public_react_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(40668);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(31621);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* __next_internal_client_entry_do_not_use__ default auto */ 






function Navbar() {
    const [nav, setNav] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const handleNav = ()=>{
        setNav(!nav);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "bg-black fixed top-0 left-0 right-0 z-50 backdrop-filter backdrop-blur-md bg-opacity-50",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex justify-between items-center h-20 max-w-[1240px] mx-auto px-4 text-white ",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex text-3xl font-bold text-[#00df9a] uppercase",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                            className: "peer",
                            href: "/",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                className: "w-10 h-10 rounded-2xl hover:scale-110 duration-300 ease-linear animate-pulse",
                                src: _public_quiz_app_logo_png__WEBPACK_IMPORTED_MODULE_3__["default"],
                                alt: _public_react_svg__WEBPACK_IMPORTED_MODULE_4__["default"]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                            className: "peer-hover:text-purple-500 transition-colors duration-300 ease-in-out peer-hover:animate-pulse",
                            href: "/",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "px-2 shadow-2xl hover:shadow-green-500 hover:text-indigo-600 ease-in-out duration-300",
                                children: "WizeWiz"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                    className: "hidden md:flex",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "p-4",
                            children: "Home"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "p-4",
                            children: "Company"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "p-4",
                            children: "Resources"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "p-4",
                            children: "About"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "p-4",
                            children: "Contact"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    onClick: handleNav,
                    className: "block md:hidden hover:cursor-pointer transition duration-300 ease-in-out",
                    children: nav ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_6__/* .AiOutlineClose */ .oHP, {
                        size: 20,
                        className: "text-gray-600 hover:text-rose-500"
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_6__/* .AiOutlineMenu */ .qTj, {
                        size: 20,
                        className: "text-gray-600 hover:text-rose-500"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                    className: `${nav ? "fixed left-0 top-0 w-[60%] h-full border-r border-r-gray-900 bg-[#000300] ease-in-out duration-500" : "ease-in-out duration-500 fixed left-[-100%]"}`,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex text-3xl font-bold text-[#00df9a] uppercase m-1.5",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    className: "peer",
                                    href: "/",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        className: "w-7 h-7 rounded-2xl hover:scale-110 duration-300 ease-linear animate-pulse m-1.5",
                                        src: _public_quiz_app_logo_png__WEBPACK_IMPORTED_MODULE_3__["default"],
                                        alt: _public_react_svg__WEBPACK_IMPORTED_MODULE_4__["default"]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    className: "peer-hover:text-purple-500 transition-colors duration-300 ease-in-out peer-hover:animate-pulse",
                                    href: "/",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "px-2 shadow-2xl hover:shadow-green-500 hover:text-indigo-600 ease-in-out duration-300",
                                        children: "WizeWiz"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "bg-[#000300] p-4 border-b border-gray-600 hover:bg-rose-500 hover:cursor-pointer active:bg-amber-300 transition duration-700 ease-in-out",
                            children: "Home"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "bg-[#000300] p-4 border-b border-gray-600 hover:bg-rose-500 hover:cursor-pointer active:bg-amber-300 transition duration-700 ease-in-out",
                            children: "Company"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "bg-[#000300] p-4 border-b border-gray-600 hover:bg-rose-500 hover:cursor-pointer active:bg-amber-300 transition duration-700 ease-in-out",
                            children: "Resources"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "bg-[#000300] p-4 border-b border-gray-600 hover:bg-rose-500 hover:cursor-pointer active:bg-amber-300 transition duration-700 ease-in-out",
                            children: "About"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "bg-[#000300] p-4 border-b border-gray-600 hover:bg-rose-500 hover:cursor-pointer active:bg-amber-300 transition duration-700 ease-in-out",
                            children: "Contact"
                        })
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 66853:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ Footer)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/react-icons/fa/index.esm.js
var index_esm = __webpack_require__(87606);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(34834);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(10993);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./public/quiz-app-logo.png
var quiz_app_logo = __webpack_require__(76107);
;// CONCATENATED MODULE: ./public/react.svg
/* harmony default export */ const react = ({"src":"/_next/static/media/react.3b0445a3.svg","height":32,"width":36,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./components/landing-page/Footer.jsx






function Footer() {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full bg-white py-16 px-4 wavy-footer",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "max-w-[1240px] mx-auto py-16 px-4 grid lg:grid-cols-3 gap-8 text-gray-300",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex text-3xl font-bold text-[#00df9a] uppercase",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    className: "peer",
                                    href: "/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: "w-10 h-10 rounded-2xl hover:scale-110 duration-300 ease-linear animate-pulse",
                                        src: quiz_app_logo/* default */.Z,
                                        alt: react
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    className: "peer-hover:text-purple-500 transition-colors duration-300 ease-in-out peer-hover:animate-pulse",
                                    href: "/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: "px-2 shadow-2xl hover:shadow-green-500 hover:text-indigo-600 ease-in-out duration-300",
                                        children: "WizeWiz"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "py-4",
                            children: "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Id odit ullam iste repellat consequatur libero reiciendis, blanditiis accusantium."
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex justify-between md:w-[75%] my-6",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* FaFacebookSquare */.R9i, {
                                    size: 30,
                                    className: "hover:cursor-pointer hover:text-orange-600 hover:scale-110 transition-all duration-500"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* FaInstagram */.Zf_, {
                                    size: 30,
                                    className: "hover:cursor-pointer hover:text-pink-500 hover:scale-110 transition-all duration-500"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* FaTwitterSquare */.N1v, {
                                    size: 30,
                                    className: "hover:cursor-pointer hover:text-blue-600 hover:scale-110 transition-all duration-500"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* FaGithubSquare */.NML, {
                                    size: 30,
                                    className: "hover:cursor-pointer hover:text-teal-600 hover:scale-110 transition-all duration-500"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* FaDribbbleSquare */.soY, {
                                    size: 30,
                                    className: "hover:cursor-pointer hover:text-yellow-300 hover:scale-110 transition-all duration-500"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "lg:col-span-2 flex justify-between mt-6",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                    className: "font-medium text-gray-400",
                                    children: "Solutions"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "py-2 text-sm",
                                            children: "Analytics"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "py-2 text-sm",
                                            children: "Marketing"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "py-2 text-sm",
                                            children: "Commerce"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "py-2 text-sm",
                                            children: "Insights"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                    className: "font-medium text-gray-400",
                                    children: "Support"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "py-2 text-sm",
                                            children: "Pricing"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "py-2 text-sm",
                                            children: "Documentation"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "py-2 text-sm",
                                            children: "Guides"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "py-2 text-sm",
                                            children: "API Status"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                    className: "font-medium text-gray-400",
                                    children: "Company"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "py-2 text-sm",
                                            children: "About"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "py-2 text-sm",
                                            children: "Blog"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "py-2 text-sm",
                                            children: "Jobs"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "py-2 text-sm",
                                            children: "Press"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "py-2 text-sm",
                                            children: "Careers"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                    className: "font-medium text-gray-400",
                                    children: "Legal"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "py-2 text-sm",
                                            children: "Claim"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "py-2 text-sm",
                                            children: "Policy"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "py-2 text-sm",
                                            children: "Terms"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 49482:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/home/runner/work/InteractiveQuizApplication/InteractiveQuizApplication/FrontEnd/interactive-quiz-app/components/landing-page/Navbar.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 76107:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/quiz-app-logo.1a3a0370.png","height":2048,"width":2048,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA/0lEQVR4nA2OPUtCYRhAz3M//MgalDIwHIQicGppaBWamhobmqOhcPJ3tNTY0g+QZtEMCwNBAgctiqiQCgnqKl3q9t7Hu50DZzhSa6RVrBzILLb0cJwkxggm/IvcValflTSe2cSNxXgeXOMN71gvLnA/nGDcT5Vmt6xOchHvO+CkGmJ1q1QOc/T6hv3KP3LZLmlgb/DmF7HHQ9JfZzx95Gh0Al5Hggxu1zRtJXh8cVgpJPB/LfoPIYW88D6K1m7aec1Yq4w9m3gsJDUjpJJETDQaBc3WnPb6eQ72ltjaNkx8obIrZOeFVkeR+kVWTehwfLrMecuFH6W8IxzVFAYwBbsDZGen4HKfAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ })

};
;