(() => {
var exports = {};
exports.id = 907;
exports.ids = [907];
exports.modules = {

/***/ 40252:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 97999:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 61090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 78652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 47244:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 21668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 66797:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppRouter: () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   LayoutRouter: () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   RenderFromTemplateContext: () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   StaticGenerationSearchParamsBailoutProvider: () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   __next_app_webpack_require__: () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   actionAsyncStorage: () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   createSearchParamsBailoutProxy: () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   decodeAction: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   decodeReply: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   preconnect: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   preloadFont: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   preloadStyle: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   renderToReadableStream: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   requestAsyncStorage: () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   serverHooks: () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   staticGenerationAsyncStorage: () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   staticGenerationBailout: () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(54592);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(76301);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57431);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(30094);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(24437);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(46127);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(45486);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(86404);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(95486);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(63332);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(27902);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(93099);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        'quiz',
        {
        children: [
        'public',
        {
        children: [
        'demo',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 44889)), "/home/runner/work/InteractiveQuizApplication/InteractiveQuizApplication/FrontEnd/interactive-quiz-app/app/quiz/public/demo/page.jsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57409)), "/home/runner/work/InteractiveQuizApplication/InteractiveQuizApplication/FrontEnd/interactive-quiz-app/app/layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["/home/runner/work/InteractiveQuizApplication/InteractiveQuizApplication/FrontEnd/interactive-quiz-app/app/quiz/public/demo/page.jsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/quiz/public/demo/page"
  

/***/ }),

/***/ 32345:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 35568))

/***/ }),

/***/ 35568:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ QuizProvider)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
;// CONCATENATED MODULE: ./components/quiz/quiz-components/Core-Compoents/QuizResultFilter.jsx


const QuizResultFilter = function({ filteredValue, handleChange, appLocale }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "quiz-result-filter",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
            value: filteredValue,
            onChange: handleChange,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                    value: "all",
                    children: appLocale.resultFilterAll
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                    value: "correct",
                    children: appLocale.resultFilterCorrect
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                    value: "incorrect",
                    children: appLocale.resultFilterIncorrect
                })
            ]
        })
    });
};
/* harmony default export */ const Core_Compoents_QuizResultFilter = (QuizResultFilter);

// EXTERNAL MODULE: ./node_modules/snarkdown/dist/snarkdown.js
var snarkdown = __webpack_require__(30757);
var snarkdown_default = /*#__PURE__*/__webpack_require__.n(snarkdown);
// EXTERNAL MODULE: ./node_modules/dompurify/dist/purify.cjs.js
var purify_cjs = __webpack_require__(62841);
var purify_cjs_default = /*#__PURE__*/__webpack_require__.n(purify_cjs);
;// CONCATENATED MODULE: ./components/quiz/quiz-components/Core-Compoents/helper.jsx


const rawMarkup = (data)=>{
    const sanitizer = (purify_cjs_default()).sanitize;
    return {
        __html: snarkdown_default()(sanitizer(data))
    };
};
const checkAnswer = (index, correctAnswer, answerSelectionType, { userInput, userAttempt, currentQuestionIndex, continueTillCorrect, showNextQuestionButton, incorrect, correct, setButtons, setCorrectAnswer, setIncorrectAnswer, setCorrect, setIncorrect, setShowNextQuestionButton, setUserInput, setUserAttempt })=>{
    const indexStr = `${index}`;
    const disabledAll = {
        0: {
            disabled: true
        },
        1: {
            disabled: true
        },
        2: {
            disabled: true
        },
        3: {
            disabled: true
        }
    };
    const userInputCopy = [
        ...userInput
    ];
    if (answerSelectionType === "single") {
        if (userInputCopy[currentQuestionIndex] === undefined) {
            userInputCopy[currentQuestionIndex] = index;
        }
        if (indexStr === correctAnswer) {
            if (incorrect.indexOf(currentQuestionIndex) < 0 && correct.indexOf(currentQuestionIndex) < 0) {
                correct.push(currentQuestionIndex);
            }
            setButtons((prevState)=>({
                    ...prevState,
                    ...disabledAll,
                    [index - 1]: {
                        className: indexStr === correctAnswer ? "correct" : "incorrect"
                    }
                }));
            setCorrectAnswer(true);
            setIncorrectAnswer(false);
            setCorrect(correct);
            setShowNextQuestionButton(true);
        } else {
            if (correct.indexOf(currentQuestionIndex) < 0 && incorrect.indexOf(currentQuestionIndex) < 0) {
                incorrect.push(currentQuestionIndex);
            }
            if (continueTillCorrect) {
                setButtons((prevState)=>({
                        ...prevState,
                        [index - 1]: {
                            disabled: !prevState[index - 1]
                        }
                    }));
            } else {
                setButtons((prevState)=>({
                        ...prevState,
                        ...disabledAll,
                        [index - 1]: {
                            className: indexStr === correctAnswer ? "correct" : "incorrect"
                        }
                    }));
                setShowNextQuestionButton(true);
            }
            setIncorrectAnswer(true);
            setCorrectAnswer(false);
            setIncorrect(incorrect);
        }
    } else {
        const maxNumberOfMultipleSelection = correctAnswer.length;
        if (userInputCopy[currentQuestionIndex] === undefined) {
            userInputCopy[currentQuestionIndex] = [];
        }
        if (userInputCopy[currentQuestionIndex].length < maxNumberOfMultipleSelection) {
            userInputCopy[currentQuestionIndex].push(index);
            if (correctAnswer.includes(index)) {
                if (userInputCopy[currentQuestionIndex].length <= maxNumberOfMultipleSelection) {
                    setButtons((prevState)=>({
                            ...prevState,
                            [index - 1]: {
                                disabled: !prevState[index - 1],
                                className: correctAnswer.includes(index) ? "correct" : "incorrect"
                            }
                        }));
                }
            } else if (userInputCopy[currentQuestionIndex].length <= maxNumberOfMultipleSelection) {
                setButtons((prevState)=>({
                        ...prevState,
                        [index - 1]: {
                            className: correctAnswer.includes(index) ? "correct" : "incorrect"
                        }
                    }));
            }
        }
        if (maxNumberOfMultipleSelection === userAttempt) {
            let cnt = 0;
            for(let i = 0; i < correctAnswer.length; i += 1){
                if (userInputCopy[currentQuestionIndex].includes(correctAnswer[i])) {
                    cnt += 1;
                }
            }
            if (cnt === maxNumberOfMultipleSelection) {
                correct.push(currentQuestionIndex);
                setCorrectAnswer(true);
                setIncorrectAnswer(false);
                setCorrect(correct);
                setShowNextQuestionButton(true);
                setUserAttempt(1);
            } else {
                incorrect.push(currentQuestionIndex);
                setIncorrectAnswer(true);
                setCorrectAnswer(false);
                setIncorrect(incorrect);
                setShowNextQuestionButton(true);
                setUserAttempt(1);
            }
        } else if (!showNextQuestionButton) {
            setUserAttempt(userAttempt + 1);
        }
    }
    setUserInput(userInputCopy);
};
const selectAnswer = (index, correctAnswer, answerSelectionType, { userInput, currentQuestionIndex, setButtons, setShowNextQuestionButton, incorrect, correct, setCorrect, setIncorrect, setUserInput })=>{
    const selectedButtons = {
        0: {
            selected: false
        },
        1: {
            selected: false
        },
        2: {
            selected: false
        },
        3: {
            selected: false
        }
    };
    const userInputCopy = [
        ...userInput
    ];
    if (answerSelectionType === "single") {
        correctAnswer = Number(correctAnswer);
        userInputCopy[currentQuestionIndex] = index;
        if (index === correctAnswer) {
            if (correct.indexOf(currentQuestionIndex) < 0) {
                correct.push(currentQuestionIndex);
            }
            if (incorrect.indexOf(currentQuestionIndex) >= 0) {
                incorrect.splice(incorrect.indexOf(currentQuestionIndex), 1);
            }
        } else {
            if (incorrect.indexOf(currentQuestionIndex) < 0) {
                incorrect.push(currentQuestionIndex);
            }
            if (correct.indexOf(currentQuestionIndex) >= 0) {
                correct.splice(correct.indexOf(currentQuestionIndex), 1);
            }
        }
        setCorrect(correct);
        setIncorrect(incorrect);
        setButtons((prevState)=>({
                ...prevState,
                ...selectedButtons,
                [index - 1]: {
                    className: "selected"
                }
            }));
        setShowNextQuestionButton(true);
    } else {
        if (userInputCopy[currentQuestionIndex] === undefined) {
            userInputCopy[currentQuestionIndex] = [];
        }
        if (userInputCopy[currentQuestionIndex].includes(index)) {
            userInputCopy[currentQuestionIndex].splice(userInputCopy[currentQuestionIndex].indexOf(index), 1);
        } else {
            userInputCopy[currentQuestionIndex].push(index);
        }
        if (userInputCopy[currentQuestionIndex].length === correctAnswer.length) {
            let exactMatch = true;
            for (const input of userInput[currentQuestionIndex]){
                if (!correctAnswer.includes(input)) {
                    exactMatch = false;
                    if (incorrect.indexOf(currentQuestionIndex) < 0) {
                        incorrect.push(currentQuestionIndex);
                    }
                    if (correct.indexOf(currentQuestionIndex) >= 0) {
                        correct.splice(correct.indexOf(currentQuestionIndex), 1);
                    }
                    break;
                }
            }
            if (exactMatch) {
                if (correct.indexOf(currentQuestionIndex) < 0) {
                    correct.push(currentQuestionIndex);
                }
                if (incorrect.indexOf(currentQuestionIndex) >= 0) {
                    incorrect.splice(incorrect.indexOf(currentQuestionIndex), 1);
                }
            }
        } else {
            if (incorrect.indexOf(currentQuestionIndex) < 0) {
                incorrect.push(currentQuestionIndex);
            }
            if (correct.indexOf(currentQuestionIndex) >= 0) {
                correct.splice(correct.indexOf(currentQuestionIndex), 1);
            }
        }
        setCorrect(correct);
        setIncorrect(incorrect);
        setButtons((prevState)=>({
                ...prevState,
                [index - 1]: {
                    className: userInputCopy[currentQuestionIndex].includes(index) ? "selected" : undefined
                }
            }));
        if (userInputCopy[currentQuestionIndex].length > 0) {
            setShowNextQuestionButton(true);
        }
    }
    setUserInput(userInputCopy);
};

;// CONCATENATED MODULE: ./components/quiz/quiz-components/Core-Compoents/Explanation.jsx

const Explanation = function({ question, isResultPage }) {
    const { explanation } = question;
    if (!explanation) {
        return null;
    }
    if (isResultPage) {
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "explanation",
            children: explanation
        });
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
            explanation
        ]
    });
};
/* harmony default export */ const Core_Compoents_Explanation = (Explanation);

;// CONCATENATED MODULE: ./components/quiz/quiz-components/Core-Compoents/InstantFeedback.jsx



const renderMessageForCorrectAnswer = (question)=>{
    const defaultMessage = "You are correct. Please click Next to continue.";
    return question.messageForCorrectAnswer || defaultMessage;
};
const renderMessageForIncorrectAnswer = (question)=>{
    const defaultMessage = "Incorrect answer. Please try again.";
    return question.messageForIncorrectAnswer || defaultMessage;
};
const InstantFeedback = function({ showInstantFeedback, incorrectAnswer, correctAnswer, question, onQuestionSubmit, userAnswer }) {
    (0,react_.useEffect)(()=>{
        if (onQuestionSubmit && (correctAnswer || incorrectAnswer)) {
            onQuestionSubmit({
                question,
                userAnswer,
                isCorrect: correctAnswer
            });
        }
    }, [
        correctAnswer,
        incorrectAnswer
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            incorrectAnswer && showInstantFeedback && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "alert incorrect",
                children: renderMessageForIncorrectAnswer(question)
            }),
            correctAnswer && showInstantFeedback && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "alert correct",
                children: [
                    renderMessageForCorrectAnswer(question),
                    /*#__PURE__*/ jsx_runtime_.jsx(Core_Compoents_Explanation, {
                        question: question,
                        isResultPage: false
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Core_Compoents_InstantFeedback = (InstantFeedback);

;// CONCATENATED MODULE: ./components/quiz/quiz-components/core-starter/Core.jsx






const Core = function({ questions, appLocale, showDefaultResult, onComplete, customResultPage, showInstantFeedback, continueTillCorrect, revealAnswerOnSubmit, allowNavigation, onQuestionSubmit }) {
    const [incorrectAnswer, setIncorrectAnswer] = (0,react_.useState)(false);
    const [correctAnswer, setCorrectAnswer] = (0,react_.useState)(false);
    const [showNextQuestionButton, setShowNextQuestionButton] = (0,react_.useState)(false);
    const [endQuiz, setEndQuiz] = (0,react_.useState)(false);
    const [currentQuestionIndex, setCurrentQuestionIndex] = (0,react_.useState)(0);
    const [buttons, setButtons] = (0,react_.useState)({});
    const [correct, setCorrect] = (0,react_.useState)([]);
    const [incorrect, setIncorrect] = (0,react_.useState)([]);
    const [userInput, setUserInput] = (0,react_.useState)([]);
    const [filteredValue, setFilteredValue] = (0,react_.useState)("all");
    const [userAttempt, setUserAttempt] = (0,react_.useState)(1);
    const [showDefaultResultState, setShowDefaultResult] = (0,react_.useState)(true);
    const [answerSelectionTypeState, setAnswerSelectionType] = (0,react_.useState)(undefined);
    const [totalPoints, setTotalPoints] = (0,react_.useState)(0);
    const [correctPoints, setCorrectPoints] = (0,react_.useState)(0);
    const [question, setQuestion] = (0,react_.useState)(questions[currentQuestionIndex]);
    const [questionSummary, setQuestionSummary] = (0,react_.useState)(undefined);
    (0,react_.useEffect)(()=>{
        setShowDefaultResult(showDefaultResult !== undefined ? showDefaultResult : true);
    }, [
        showDefaultResult
    ]);
    (0,react_.useEffect)(()=>{
        setQuestion(questions[currentQuestionIndex]);
    }, [
        currentQuestionIndex
    ]);
    (0,react_.useEffect)(()=>{
        const { answerSelectionType } = question;
        // Default single to avoid code breaking due to automatic version upgrade
        setAnswerSelectionType(answerSelectionType || "single");
    }, [
        question,
        currentQuestionIndex
    ]);
    (0,react_.useEffect)(()=>{
        if (endQuiz) {
            let totalPointsTemp = 0;
            let correctPointsTemp = 0;
            for(let i = 0; i < questions.length; i += 1){
                let point = questions[i].point || 0;
                if (typeof point === "string" || point instanceof String) {
                    point = parseInt(point);
                }
                totalPointsTemp += point;
                if (correct.includes(i)) {
                    correctPointsTemp += point;
                }
            }
            setTotalPoints(totalPointsTemp);
            setCorrectPoints(correctPointsTemp);
        }
    }, [
        endQuiz
    ]);
    (0,react_.useEffect)(()=>{
        setQuestionSummary({
            numberOfQuestions: questions.length,
            numberOfCorrectAnswers: correct.length,
            numberOfIncorrectAnswers: incorrect.length,
            questions,
            userInput,
            totalPoints,
            correctPoints
        });
    }, [
        totalPoints,
        correctPoints
    ]);
    (0,react_.useEffect)(()=>{
        if (endQuiz && onComplete !== undefined && questionSummary !== undefined) {
            onComplete(questionSummary);
        }
    }, [
        questionSummary
    ]);
    const nextQuestion = (currentQuestionIdx)=>{
        setIncorrectAnswer(false);
        setCorrectAnswer(false);
        setShowNextQuestionButton(false);
        setButtons({});
        if (currentQuestionIdx + 1 === questions.length) {
            if (userInput.length !== questions.length) {
                alert("Quiz is incomplete");
            } else if (allowNavigation) {
                const submitQuiz = confirm("You have finished all the questions. Submit Quiz now?");
                if (submitQuiz) {
                    setEndQuiz(true);
                }
            } else {
                setEndQuiz(true);
            }
        } else {
            setCurrentQuestionIndex(currentQuestionIdx + 1);
        }
        window.scrollTo(0, 0);
    };
    const handleChange = (event)=>{
        setFilteredValue(event.target.value);
    };
    const renderAnswerInResult = (question, userInputIndex)=>{
        const { answers, correctAnswer, questionType } = question;
        let { answerSelectionType } = question;
        let answerBtnCorrectClassName;
        let answerBtnIncorrectClassName;
        // Default single to avoid code breaking due to automatic version upgrade
        answerSelectionType = answerSelectionType || "single";
        return answers.map((answer, index)=>{
            if (answerSelectionType === "single") {
                // correctAnswer - is string
                answerBtnCorrectClassName = `${index + 1}` === correctAnswer ? "correct" : "";
                answerBtnIncorrectClassName = `${userInputIndex}` !== correctAnswer && `${index + 1}` === `${userInputIndex}` ? "incorrect" : "";
            } else {
                // correctAnswer - is array of numbers
                answerBtnCorrectClassName = correctAnswer.includes(index + 1) ? "correct" : "";
                answerBtnIncorrectClassName = !correctAnswer.includes(index + 1) && userInputIndex.includes(index + 1) ? "incorrect" : "";
            }
            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                    disabled: true,
                    className: `answerBtn btn ${answerBtnCorrectClassName}${answerBtnIncorrectClassName}`,
                    children: [
                        questionType === "text" && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: answer
                        }),
                        questionType === "photo" && /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: answer,
                            alt: "image"
                        })
                    ]
                })
            }, index);
        });
    };
    const renderQuizResultQuestions = (0,react_.useCallback)(()=>{
        let filteredQuestions;
        let filteredUserInput;
        if (filteredValue !== "all") {
            if (filteredValue === "correct") {
                filteredQuestions = questions.filter((question, index)=>correct.indexOf(index) !== -1);
                filteredUserInput = userInput.filter((input, index)=>correct.indexOf(index) !== -1);
            } else {
                filteredQuestions = questions.filter((question, index)=>incorrect.indexOf(index) !== -1);
                filteredUserInput = userInput.filter((input, index)=>incorrect.indexOf(index) !== -1);
            }
        }
        return (filteredQuestions || questions).map((question, index)=>{
            const userInputIndex = filteredUserInput ? filteredUserInput[index] : userInput[index];
            // Default single to avoid code breaking due to automatic version upgrade
            const answerSelectionType = question.answerSelectionType || "single";
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "result-answer-wrapper",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        dangerouslySetInnerHTML: rawMarkup(`Q${question.questionIndex}: ${question.question}`)
                    }),
                    question.questionPic && /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: question.questionPic,
                        alt: "image"
                    }),
                    renderTags(answerSelectionType, question.correctAnswer.length, question.segment),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "result-answer",
                        children: renderAnswerInResult(question, userInputIndex)
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Core_Compoents_Explanation, {
                        question: question,
                        isResultPage: true
                    })
                ]
            }, index + 1);
        });
    }, [
        endQuiz,
        filteredValue
    ]);
    const renderAnswers = (question, buttons)=>{
        const { answers, correctAnswer, questionType, questionIndex } = question;
        let { answerSelectionType } = question;
        const onClickAnswer = (index)=>checkAnswer(index + 1, correctAnswer, answerSelectionType, {
                userInput,
                userAttempt,
                currentQuestionIndex,
                continueTillCorrect,
                showNextQuestionButton,
                incorrect,
                correct,
                setButtons,
                setCorrectAnswer,
                setIncorrectAnswer,
                setCorrect,
                setIncorrect,
                setShowNextQuestionButton,
                setUserInput,
                setUserAttempt
            });
        const onSelectAnswer = (index)=>selectAnswer(index + 1, correctAnswer, answerSelectionType, {
                userInput,
                currentQuestionIndex,
                setButtons,
                setShowNextQuestionButton,
                incorrect,
                correct,
                setCorrect,
                setIncorrect,
                setUserInput
            });
        const checkSelectedAnswer = (index)=>{
            if (userInput[questionIndex - 1] === undefined) {
                return false;
            }
            if (answerSelectionType === "single") {
                return userInput[questionIndex - 1] === index;
            }
            return Array.isArray(userInput[questionIndex - 1]) && userInput[questionIndex - 1].includes(index);
        };
        // Default single to avoid code breaking due to automatic version upgrade
        answerSelectionType = answerSelectionType || "single";
        return answers.map((answer, index)=>/*#__PURE__*/ jsx_runtime_.jsx(react_.Fragment, {
                children: buttons[index] !== undefined ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                    type: "button",
                    disabled: buttons[index].disabled || false,
                    className: `${buttons[index].className} answerBtn btn`,
                    onClick: ()=>revealAnswerOnSubmit ? onSelectAnswer(index) : onClickAnswer(index),
                    children: [
                        questionType === "text" && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: answer
                        }),
                        questionType === "photo" && /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: answer,
                            alt: "image"
                        })
                    ]
                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                    type: "button",
                    onClick: ()=>revealAnswerOnSubmit ? onSelectAnswer(index) : onClickAnswer(index),
                    className: `answerBtn btn ${allowNavigation && checkSelectedAnswer(index + 1) ? "selected" : null}`,
                    children: [
                        questionType === "text" && answer,
                        questionType === "photo" && /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: answer,
                            alt: "image"
                        })
                    ]
                })
            }, index));
    };
    const renderTags = (answerSelectionType, numberOfSelection, segment)=>{
        const { singleSelectionTagText, multipleSelectionTagText, pickNumberOfSelection } = appLocale;
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "tag-container",
            children: [
                answerSelectionType === "single" && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "single selection-tag",
                    children: singleSelectionTagText
                }),
                answerSelectionType === "multiple" && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "multiple selection-tag",
                    children: multipleSelectionTagText
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "number-of-selection",
                    children: pickNumberOfSelection.replace("<numberOfSelection>", numberOfSelection)
                }),
                segment && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "selection-tag segment",
                    children: segment
                })
            ]
        });
    };
    const renderResult = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "card-body",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    children: appLocale.resultPageHeaderText.replace("<correctIndexLength>", correct.length).replace("<questionLength>", questions.length)
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    children: appLocale.resultPagePoint.replace("<correctPoints>", correctPoints).replace("<totalPoints>", totalPoints)
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                /*#__PURE__*/ jsx_runtime_.jsx(Core_Compoents_QuizResultFilter, {
                    filteredValue: filteredValue,
                    handleChange: handleChange,
                    appLocale: appLocale
                }),
                renderQuizResultQuestions()
            ]
        });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "questionWrapper",
        children: [
            !endQuiz && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "questionWrapperBody",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "questionModal",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Core_Compoents_InstantFeedback, {
                            question: question,
                            showInstantFeedback: showInstantFeedback,
                            correctAnswer: correctAnswer,
                            incorrectAnswer: incorrectAnswer,
                            onQuestionSubmit: onQuestionSubmit,
                            userAnswer: [
                                ...userInput
                            ].pop()
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            appLocale.question,
                            " ",
                            currentQuestionIndex + 1,
                            ":"
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        dangerouslySetInnerHTML: rawMarkup(question && question.question)
                    }),
                    question && question.questionPic && /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: question.questionPic,
                        alt: "image"
                    }),
                    question && renderTags(answerSelectionTypeState, question.correctAnswer.length, question.segment),
                    question && renderAnswers(question, buttons),
                    (showNextQuestionButton || allowNavigation) && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "questionBtnContainer",
                        children: [
                            allowNavigation && currentQuestionIndex > 0 && /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                onClick: ()=>nextQuestion(currentQuestionIndex - 2),
                                className: "prevQuestionBtn btn",
                                type: "button",
                                children: appLocale.prevQuestionBtn
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                onClick: ()=>nextQuestion(currentQuestionIndex),
                                className: "nextQuestionBtn btn",
                                type: "button",
                                children: appLocale.nextQuestionBtn
                            })
                        ]
                    })
                ]
            }),
            endQuiz && showDefaultResultState && customResultPage === undefined && renderResult(),
            endQuiz && !showDefaultResultState && customResultPage !== undefined && customResultPage(questionSummary)
        ]
    });
};
/* harmony default export */ const core_starter_Core = (Core);

;// CONCATENATED MODULE: ./components/quiz/quiz-components/core-starter/Locale.jsx
const defaultLocale = {
    landingHeaderText: "<questionLength> Questions",
    question: "Question",
    startQuizBtn: "Start Quiz",
    resultFilterAll: "All",
    resultFilterCorrect: "Correct",
    resultFilterIncorrect: "Incorrect",
    nextQuestionBtn: "Next",
    prevQuestionBtn: "Prev",
    resultPageHeaderText: "You have completed the quiz." + " You got <correctIndexLength> out of <questionLength> questions.",
    resultPagePoint: "You scored <correctPoints> out of <totalPoints>.",
    singleSelectionTagText: "Single Selection",
    multipleSelectionTagText: "Multiple Selection",
    pickNumberOfSelection: "Pick <numberOfSelection>"
};
/* harmony default export */ const Locale = (defaultLocale);

;// CONCATENATED MODULE: ./components/quiz/quiz-components/core-starter/Quiz.jsx




const Quiz = function({ quiz, shuffle, showDefaultResult, onComplete, customResultPage, showInstantFeedback, continueTillCorrect, revealAnswerOnSubmit, allowNavigation, onQuestionSubmit, disableSynopsis }) {
    const [start, setStart] = (0,react_.useState)(false);
    const [questions, setQuestions] = (0,react_.useState)(quiz.questions);
    const nrOfQuestions = quiz.nrOfQuestions && quiz.nrOfQuestions < quiz.questions.length ? quiz.nrOfQuestions : quiz.questions.length;
    const shuffleQuestions = (0,react_.useCallback)((q)=>{
        for(let i = q.length - 1; i > 0; i -= 1){
            const j = Math.floor(Math.random() * (i + 1));
            [q[i], q[j]] = [
                q[j],
                q[i]
            ];
        }
        q.length = nrOfQuestions;
        return q;
    }, []);
    (0,react_.useEffect)(()=>{
        if (disableSynopsis) setStart(true);
    }, []);
    (0,react_.useEffect)(()=>{
        if (shuffle) {
            setQuestions(shuffleQuestions(quiz.questions));
        } else {
            quiz.questions.length = nrOfQuestions;
            setQuestions(quiz.questions);
        }
        setQuestions(questions.map((question, index)=>({
                ...question,
                questionIndex: index + 1
            })));
    }, [
        start
    ]);
    const validateQuiz = (q)=>{
        if (!q) {
            console.error("Quiz object is required.");
            return false;
        }
        for(let i = 0; i < questions.length; i += 1){
            const { question, questionType, answerSelectionType, answers, correctAnswer } = questions[i];
            if (!question) {
                console.error("Field 'question' is required.");
                return false;
            }
            if (!questionType) {
                console.error("Field 'questionType' is required.");
                return false;
            }
            if (questionType !== "text" && questionType !== "photo") {
                console.error("The value of 'questionType' is either 'text' or 'photo'.");
                return false;
            }
            if (!answers) {
                console.error("Field 'answers' is required.");
                return false;
            }
            if (!Array.isArray(answers)) {
                console.error("Field 'answers' has to be an Array");
                return false;
            }
            if (!correctAnswer) {
                console.error("Field 'correctAnswer' is required.");
                return false;
            }
            let selectType = answerSelectionType;
            if (!answerSelectionType) {
                // Default single to avoid code breaking due to automatic version upgrade
                console.warn("Field answerSelectionType should be defined" + " since v0.3.0. Use single by default.");
                selectType = answerSelectionType || "single";
            }
            if (selectType === "single" && !(typeof selectType === "string" || selectType instanceof String)) {
                console.error("answerSelectionType is single but" + " expecting String in the field correctAnswer");
                return false;
            }
            if (selectType === "multiple" && !Array.isArray(correctAnswer)) {
                console.error("answerSelectionType is multiple but" + " expecting Array in the field correctAnswer");
                return false;
            }
        }
        return true;
    };
    if (!validateQuiz(quiz)) {
        return null;
    }
    const appLocale = {
        ...Locale,
        ...quiz.appLocale
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "react-quiz-container",
        children: [
            !start && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        children: quiz.quizTitle
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: appLocale.landingHeaderText.replace("<questionLength>", nrOfQuestions)
                    }),
                    quiz.quizSynopsis && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "quiz-synopsis",
                        children: quiz.quizSynopsis
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "startQuizWrapper",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            onClick: ()=>setStart(true),
                            className: "startQuizBtn btn",
                            children: appLocale.startQuizBtn
                        })
                    })
                ]
            }),
            start && /*#__PURE__*/ jsx_runtime_.jsx(core_starter_Core, {
                questions: questions,
                showDefaultResult: showDefaultResult,
                onComplete: onComplete,
                customResultPage: customResultPage,
                showInstantFeedback: showInstantFeedback,
                continueTillCorrect: continueTillCorrect,
                revealAnswerOnSubmit: revealAnswerOnSubmit,
                allowNavigation: allowNavigation,
                appLocale: appLocale,
                onQuestionSubmit: onQuestionSubmit
            })
        ]
    });
};
/* harmony default export */ const core_starter_Quiz = (Quiz);

;// CONCATENATED MODULE: ./components/quiz/quiz-wrapper/QuizProvider.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


function QuizProvider({ quiz }) {
    const [quizResult, setQuizResult] = (0,react_.useState)();
    console.log("I am trying to provide some data ");
    console.log(quiz);
    return /*#__PURE__*/ jsx_runtime_.jsx(core_starter_Quiz, {
        quiz: quiz,
        shuffle: true,
        // showInstantFeedback
        // continueTillCorrect
        onComplete: setQuizResult,
        onQuestionSubmit: (obj)=>console.log("user question results:", obj),
        disableSynopsis: false,
        // revealAnswerOnSubmit
        allowNavigation: true
    });
}


/***/ }),

/***/ 44889:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ DemoQuiz),
  generateMetadata: () => (/* binding */ generateMetadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21313);
;// CONCATENATED MODULE: ./components/quiz/quiz-wrapper/QuizProvider.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`/home/runner/work/InteractiveQuizApplication/InteractiveQuizApplication/FrontEnd/interactive-quiz-app/components/quiz/quiz-wrapper/QuizProvider.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const QuizProvider = (__default__);
;// CONCATENATED MODULE: ./app/quiz/public/demo/page.jsx


async function generateMetadata() {
    const response = await fetch("http://localhost:8080/api/v1/quiz/public/demo/getDemoQuiz/1", {
        next: {
            revalidate: 60
        }
    });
    if (!response.ok) {
        throw Error("OPPS FIELD TO FETCH THE DATA FROM BACKEND");
    }
    const data = await response.json();
    // console.log(data);
    const { quiz } = data;
    const { quizTitle, quizSynopsis } = quiz;
    return {
        title: quizTitle,
        description: quizSynopsis
    };
}
async function DemoQuiz() {
    const response = await fetch("http://localhost:8080/api/v1/quiz/public/demo/getDemoQuiz/1", {
        next: {
            revalidate: 60
        }
    });
    if (!response.ok) {
        throw Error("OPPS FIELD TO FETCH THE DATA FROM BACKEND");
    }
    const data = await response.json();
    const { quiz } = data;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "flex items-center justify-center",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "flex justify-center items-center w-[1280px]",
            children: /*#__PURE__*/ jsx_runtime_.jsx(QuizProvider, {
                quiz: quiz
            })
        })
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [381,633,547,286], () => (__webpack_exec__(66797)));
module.exports = __webpack_exports__;

})();